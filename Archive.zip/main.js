$(document).ready(function() {
    $("#flame").on("click", function() {
        window.location.href = "kata.html";
    });
});
